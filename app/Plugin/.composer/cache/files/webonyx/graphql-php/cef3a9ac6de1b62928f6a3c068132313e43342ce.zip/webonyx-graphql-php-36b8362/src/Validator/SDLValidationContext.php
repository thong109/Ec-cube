<?php

declare(strict_types=1);

namespace GraphQL\Validator;

class SDLValidationContext extends ASTValidationContext
{
}
